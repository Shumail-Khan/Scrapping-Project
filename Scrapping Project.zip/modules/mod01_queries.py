# modules/01_queries.py

def get_queries(query_text):
    return [{
        "query_id": "Q1",
        "query_text": query_text
    }]
